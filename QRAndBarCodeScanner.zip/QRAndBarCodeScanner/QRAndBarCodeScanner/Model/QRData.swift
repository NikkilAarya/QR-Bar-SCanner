//
//  QRData.swift
//  QRAndBarCodeScanner
//
//  Created by Apple on 08/10/21.
//

import Foundation

struct QRData {
    var codeString: String?
}

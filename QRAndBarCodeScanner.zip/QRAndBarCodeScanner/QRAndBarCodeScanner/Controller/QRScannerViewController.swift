//
//  QRScannerViewController.swift
//  QRAndBarCodeScanner
//
//  Created by Apple on 08/10/21.
//

import Foundation
import UIKit
import AVFoundation



class QRScannerViewController: UIViewController {
    
    @IBOutlet weak var scannerView: QRScannerView! {
        didSet {
            scannerView.delegate = self
        }
    }
    @IBOutlet weak var scanButton: UIButton! {
        didSet {
            scanButton.setTitle("STOP", for: .normal)
        }
    }
    @IBOutlet weak var rectOfInterestView: CaptureLineDraw!
    
    var qrData: QRData? = nil {
        didSet {
            if qrData != nil {
                self.performSegue(withIdentifier: "detailSeuge", sender: self)
            }
        }
    }
    var didAddTransparentView = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
 
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
  
        if !scannerView.isRunning {
            scannerView.rectOfInterest = rectOfInterestView.frame
            scannerView.startScanning()
            

        }
    }
    override func viewDidLayoutSubviews() {
        if !didAddTransparentView{
        didAddTransparentView = true
        let transparentView = UIView(frame: self.view.frame)
        transparentView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        transparentView.makeClearHole(rect: rectOfInterestView.frame)
        self.view.insertSubview(transparentView, belowSubview: scanButton)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if !scannerView.isRunning {
            scannerView.stopScanning()
        }
    }

    @IBAction func scanButtonAction(_ sender: UIButton) {
        scannerView.isRunning ? scannerView.stopScanning() : scannerView.startScanning()
        let buttonTitle = scannerView.isRunning ? "STOP" : "SCAN"
        sender.setTitle(buttonTitle, for: .normal)
    }

}


extension QRScannerViewController: QRScannerViewDelegate {
    func qrScanningDidStop() {
        let buttonTitle = scannerView.isRunning ? "STOP" : "SCAN"
        scanButton.setTitle(buttonTitle, for: .normal)
    }
    
    func qrScanningDidFail() {
        presentAlert(withTitle: "Error", message: "Scanning Failed. Please try again")
    }
    
    func qrScanningSucceededWithCode(_ str: String?) {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        self.qrData = QRData(codeString: str)
    }
    
    
    
}


extension QRScannerViewController {
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailSeuge", let viewController = segue.destination as? DetailViewController {
            viewController.qrData = self.qrData
        }
    }
}






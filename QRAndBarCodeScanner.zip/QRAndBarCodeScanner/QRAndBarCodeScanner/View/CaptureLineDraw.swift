//
//  CaptureLineDraw.swift
//  QRAndBarCodeScanner
//
//  Created by Apple on 08/10/21.
//


import UIKit

class CaptureLineDraw: UIView {
    var color: UIColor = .systemTeal


   required init?(coder aDecoder: NSCoder) {
       super.init(coder: aDecoder)
      
   }
   override init(frame: CGRect) {
       super.init(frame: frame)
       backgroundColor = .clear
   }


   override func draw(_ rect: CGRect) {
       guard let context = UIGraphicsGetCurrentContext() else { return }
       context.setLineWidth(3 * UIScreen.main.scale)
       context.setStrokeColor(color.cgColor)
       context.setLineJoin(.bevel)
       context.setLineCap(.square)

       let braceLength = bounds.width * 0.15

       var origin: CGPoint

       // Top Left
       origin = bounds.origin
       context.addLines(between: [origin, origin + CGPoint(x: braceLength, y: 0)])
       context.addLines(between: [origin, origin + CGPoint(x: 0, y: braceLength)])

       // Top Right
       origin = bounds.origin + CGPoint(x: bounds.width, y: 0)
       context.addLines(between: [origin, origin - CGPoint(x: braceLength, y: 0)])
       context.addLines(between: [origin, origin + CGPoint(x: 0, y: braceLength)])

       // Bottom Left
       origin = bounds.origin + CGPoint(x: 0, y: bounds.height)
       context.addLines(between: [origin, origin + CGPoint(x: braceLength, y: 0)])
       context.addLines(between: [origin, origin - CGPoint(x: 0, y: braceLength)])

       // Bottom Right
       origin = bounds.origin + CGPoint(x: bounds.width, y: bounds.height)
       context.addLines(between: [origin, origin - CGPoint(x: braceLength, y: 0)])
       context.addLines(between: [origin, origin - CGPoint(x: 0, y: braceLength)])

       context.strokePath()
   }
}


extension CGPoint {
   static func + (lhs: CGPoint, rhs: CGPoint) -> CGPoint {
       CGPoint(x: lhs.x + rhs.x, y: lhs.y + rhs.y)
   }

   static func += (lhs: inout CGPoint, rhs: CGPoint) {
       lhs = lhs + rhs
   }

   static func - (lhs: CGPoint, rhs: CGPoint) -> CGPoint {
       CGPoint(x: lhs.x - rhs.x, y: lhs.y - rhs.y)
   }

   static func / (lhs: CGPoint, rhs: CGFloat) -> CGPoint {
       CGPoint(x: lhs.x / rhs, y: lhs.y / rhs)
   }
}
